# FocusTimer PWA
App pronto para publicar na **Microsoft Store** via **PWA Builder**.

## Como publicar (passo a passo)
1. Crie um repositório no GitHub e suba estes arquivos.
2. Ative o **GitHub Pages** (Settings → Pages → Deploy from branch → `main` → `/root`).
3. Acesse o seu site (ex.: `https://seuusuario.github.io/seu-repo/`). Ele já funciona offline e pode ser instalado.
4. Entre em **https://www.pwabuilder.com** → cole a URL do seu site → **Start**.
5. Clique em **Store → Microsoft** e gere o pacote.
6. No Partner Center, escolha **Novo produto → Aplicativo MSIX ou PWA** e envie o pacote gerado.
